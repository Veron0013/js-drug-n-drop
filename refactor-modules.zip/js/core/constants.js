export const SELECT_TAP_TOLERANCE_PX = 8;

export const CLASSES = Object.freeze({
  mark: 'mark-span',
  selected: 'is-selected',
  dragging: 'is-dragging',
  floating: 'floating-span',
  placeholder: 'placeholder',
  ghost: 'drag-ghost',
  marqueeActive: 'is-drawing',
});
