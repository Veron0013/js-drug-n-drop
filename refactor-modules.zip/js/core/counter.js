import { CLASSES } from './constants.js';

export function createCounter({ lineEl, selectedCountEl }) {
  const countSelected = () => {
    const inLine = lineEl.querySelectorAll(`.${CLASSES.selected}`).length;
    const floating = document.querySelectorAll(`.${CLASSES.floating}.${CLASSES.selected}`).length;
    return inLine + floating;
  };

  const update = () => {
    selectedCountEl.textContent = String(countSelected());
  };

  return Object.freeze({ update, countSelected });
}
