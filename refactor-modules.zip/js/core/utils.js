export const qs = (sel, root = document) => root.querySelector(sel);

export function escapeHtml(str) {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

export function rectFromPoints(a, b) {
  const left = Math.min(a.x, b.x);
  const top = Math.min(a.y, b.y);
  const right = Math.max(a.x, b.x);
  const bottom = Math.max(a.y, b.y);
  return { left, top, right, bottom, width: right - left, height: bottom - top };
}

export function rectsIntersect(r1, r2) {
  return r1.left < r2.right && r1.right > r2.left && r1.top < r2.bottom && r1.bottom > r2.top;
}

export function swapNodes(a, b) {
  if (!a || !b || a === b) return false;

  const aParent = a.parentNode;
  const bParent = b.parentNode;
  if (!aParent || !bParent) return false;

  const aMarker = document.createComment('swap-a');
  const bMarker = document.createComment('swap-b');

  aParent.insertBefore(aMarker, a);
  bParent.insertBefore(bMarker, b);

  aParent.replaceChild(b, aMarker);
  bParent.replaceChild(a, bMarker);

  return true;
}
