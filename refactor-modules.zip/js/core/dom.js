export function getDom() {
  const dom = {
    form: document.querySelector('#textForm'),
    input: document.querySelector('#textInput'),
    line: document.querySelector('#line'),
    marquee: document.querySelector('#marquee'),
    selectedCount: document.querySelector('#selectedCount'),
    body: document.body,
  };

  if (!dom.form || !dom.input || !dom.line || !dom.marquee || !dom.selectedCount) {
    throw new Error('Required DOM nodes are missing. Check HTML ids.');
  }

  return Object.freeze(dom);
}
