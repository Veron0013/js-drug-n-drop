import { escapeHtml } from '../core/utils.js';
import { CLASSES } from '../core/constants.js';

function createSpanHTML(text) {
  return [...text]
    .map((ch, i) => `<span class="${CLASSES.mark}" id="sp-${i}">${escapeHtml(ch)}</span>`)
    .join('');
}

export function createRenderer({ lineEl, counter }) {
  const renderTextLine = (text) => {
    lineEl.innerHTML = createSpanHTML(text);
    counter.update();
  };

  return Object.freeze({ renderTextLine });
}
