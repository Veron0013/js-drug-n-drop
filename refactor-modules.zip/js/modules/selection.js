import { SELECT_TAP_TOLERANCE_PX, CLASSES } from '../core/constants.js';
import { rectFromPoints, rectsIntersect } from '../core/utils.js';

function closestCharTarget(node) {
  return node?.closest?.(`span.${CLASSES.mark}, span.${CLASSES.floating}`) ?? null;
}

function setSelected(el, value) {
  el.classList.toggle(CLASSES.selected, Boolean(value));
}

function toggleSelected(el) {
  el.classList.toggle(CLASSES.selected);
}

export function createSelectionController({ lineEl, marqueeEl, counter }) {
  let active = false;
  let start = null;
  let last = null;
  let rafId = 0;

  const applyMarqueeRect = (r) => {
    marqueeEl.style.left = `${r.left}px`;
    marqueeEl.style.top = `${r.top}px`;
    marqueeEl.style.width = `${r.width}px`;
    marqueeEl.style.height = `${r.height}px`;
  };

  const clearMarquee = () => {
    marqueeEl.classList.remove(CLASSES.marqueeActive);
    marqueeEl.style.left = '0px';
    marqueeEl.style.top = '0px';
    marqueeEl.style.width = '0px';
    marqueeEl.style.height = '0px';
  };

  const begin = (point) => {
    active = true;
    start = point;
    last = point;
    marqueeEl.classList.add(CLASSES.marqueeActive);
    applyMarqueeRect(rectFromPoints(point, point));
  };

  const move = (point) => {
    if (!active || !start) return;
    last = point;

    if (rafId) return;
    rafId = requestAnimationFrame(() => {
      rafId = 0;
      applyMarqueeRect(rectFromPoints(start, last ?? start));
    });
  };

  const end = (endPoint, originalTarget) => {
    if (!active || !start) return;

    const r = rectFromPoints(start, endPoint);
    const isClick = r.width <= SELECT_TAP_TOLERANCE_PX && r.height <= SELECT_TAP_TOLERANCE_PX;

    clearMarquee();

    if (isClick) {
      const el = closestCharTarget(originalTarget);
      if (el) toggleSelected(el);
      counter.update();
      return;
    }

    const chars = lineEl.querySelectorAll(`span.${CLASSES.mark}:not(.${CLASSES.placeholder})`);
    for (const el of chars) {
      const br = el.getBoundingClientRect();
      const elRect = { left: br.left, top: br.top, right: br.right, bottom: br.bottom };
      if (rectsIntersect(r, elRect)) setSelected(el, true);
    }

    counter.update();
  };

  const cancel = () => {
    active = false;
    start = null;
    last = null;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = 0;
    clearMarquee();
  };

  const isActive = () => active;

  return Object.freeze({ begin, move, end, cancel, isActive });
}
