import { CLASSES } from '../core/constants.js';
import { swapNodes } from '../core/utils.js';

function isSelected(el) {
  return el.classList.contains(CLASSES.selected);
}

function isLineChar(el) {
  return el?.classList?.contains(CLASSES.mark) && !el.classList.contains(CLASSES.placeholder);
}

function isPlaceholder(el) {
  return el?.classList?.contains(CLASSES.placeholder) && el?.dataset?.placeholder === 'true';
}

function isFloating(el) {
  return el?.classList?.contains(CLASSES.floating);
}

function createPlaceholderLike(span) {
  const ph = document.createElement('span');
  ph.classList.add(CLASSES.mark, CLASSES.placeholder);
  ph.dataset.placeholder = 'true';
  if (span.classList.contains(CLASSES.selected)) ph.classList.add(CLASSES.selected);
  ph.textContent = '';
  return ph;
}

export function createDragController({ bodyEl, counter }) {
  const state = {
    active: false,
    draggedEl: null,
    ghostEl: null,
    sourcePlaceholder: null,
    startedFromLine: false,
  };

  const moveGhostTo = (point) => {
    if (!state.ghostEl) return;
    state.ghostEl.style.left = `${point.x}px`;
    state.ghostEl.style.top = `${point.y}px`;
  };

  const ensureInline = (el) => {
    if (!isFloating(el)) return;
    el.classList.remove(CLASSES.floating);
    el.style.position = '';
    el.style.left = '';
    el.style.top = '';
    el.classList.add(CLASSES.mark);
  };

  const begin = (target, point) => {
    if (!target || !isSelected(target)) return false;

    state.active = true;
    state.draggedEl = target;
    state.startedFromLine = isLineChar(target);

    if (state.startedFromLine) {
      const ph = createPlaceholderLike(target);
      target.replaceWith(ph);
      state.sourcePlaceholder = ph;
    } else {
      state.sourcePlaceholder = null;
    }

    target.classList.add(CLASSES.dragging);

    const ghost = document.createElement('div');
    ghost.className = CLASSES.ghost;
    ghost.textContent = target.textContent ?? '';
    bodyEl.append(ghost);
    state.ghostEl = ghost;

    moveGhostTo(point);
    return true;
  };

  const move = (point) => {
    if (!state.active) return;
    moveGhostTo(point);
  };

  const end = (dropPoint) => {
    if (!state.active || !state.draggedEl) return;

    const dragged = state.draggedEl;

    if (state.ghostEl) state.ghostEl.remove();
    state.ghostEl = null;
    dragged.classList.remove(CLASSES.dragging);

    const pointerNode = document.elementFromPoint(dropPoint.x, dropPoint.y);
    const dropChar = pointerNode?.closest?.(`span.${CLASSES.mark}`) ?? null;

    if (dropChar && isPlaceholder(dropChar)) {
      ensureInline(dragged);
      dropChar.replaceWith(dragged);
      cleanup();
      counter.update();
      return;
    }

    if (dropChar && dropChar !== dragged) {
      if (state.startedFromLine && state.sourcePlaceholder) {
        const marker = document.createComment('drop-marker');
        dropChar.before(marker);

        state.sourcePlaceholder.replaceWith(dropChar);
        marker.replaceWith(dragged);

        cleanup();
        counter.update();
        return;
      }

      ensureInline(dragged);
      swapNodes(dropChar, dragged);

      cleanup();
      counter.update();
      return;
    }

    if (state.startedFromLine) {
      dragged.classList.remove(CLASSES.mark);
      dragged.classList.add(CLASSES.floating);
      dragged.style.position = 'fixed';
      dragged.style.left = `${dropPoint.x}px`;
      dragged.style.top = `${dropPoint.y}px`;

      bodyEl.append(dragged);
    } else {
      dragged.style.position = 'fixed';
      dragged.style.left = `${dropPoint.x}px`;
      dragged.style.top = `${dropPoint.y}px`;
    }

    cleanup();
    counter.update();
  };

  const cleanup = () => {
    state.active = false;
    state.draggedEl = null;
    state.startedFromLine = false;
    state.sourcePlaceholder = null;
  };

  const isActive = () => state.active;

  return Object.freeze({ begin, move, end, isActive });
}
