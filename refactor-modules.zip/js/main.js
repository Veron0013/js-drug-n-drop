import { getDom } from './core/dom.js';
import { createCounter } from './core/counter.js';
import { createRenderer } from './modules/render.js';
import { createSelectionController } from './modules/selection.js';
import { createDragController } from './modules/drag.js';

const dom = getDom();

const counter = createCounter({ lineEl: dom.line, selectedCountEl: dom.selectedCount });
const renderer = createRenderer({ lineEl: dom.line, counter });

const selection = createSelectionController({
  lineEl: dom.line,
  marqueeEl: dom.marquee,
  counter,
});

const drag = createDragController({
  bodyEl: dom.body,
  counter,
});

function onSubmit(e) {
  e.preventDefault();
  const text = dom.input.value.trim();
  renderer.renderTextLine(text);
  dom.form.reset();
}

function onPointerDown(e) {
  if (e.button !== 0) return;

  const point = { x: e.clientX, y: e.clientY };

  if (e.ctrlKey) {
    selection.begin(point);
    return;
  }

  const target = e.target?.closest?.('span.mark-span, span.floating-span');
  if (!target) return;

  e.preventDefault();
  drag.begin(target, point);
}

function onPointerMove(e) {
  const point = { x: e.clientX, y: e.clientY };

  if (drag.isActive()) {
    drag.move(point);
    return;
  }

  if (selection.isActive()) {
    selection.move(point);
  }
}

function onPointerUp(e) {
  const point = { x: e.clientX, y: e.clientY };

  if (selection.isActive()) {
    selection.end(point, e.target);
    selection.cancel();
    return;
  }

  if (drag.isActive()) {
    drag.end(point);
  }
}

dom.form.addEventListener('submit', onSubmit);
document.addEventListener('pointerdown', onPointerDown);
document.addEventListener('pointermove', onPointerMove);
document.addEventListener('pointerup', onPointerUp);

counter.update();
